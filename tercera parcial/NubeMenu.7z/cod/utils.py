from tkinter import filedialog
import pyttsx3
import speech_recognition as sr
from pydub import AudioSegment
from pydub.playback import play
import subprocess

def convertir_a_exe(filepath):
    result = subprocess.run(['pyinstaller', '--onefile', filepath], capture_output=True, text=True)
    if result.returncode == 0:
        return "El archivo .py se ha convertido a ejecutable."
    else:
        return f"No se pudo convertir el archivo. Error: {result.stderr}"

def grabar_audio():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        audio = recognizer.listen(source)
        try:
            text = recognizer.recognize_google(audio, language='es-ES')
            return text
        except sr.UnknownValueError:
            return "No se pudo entender el audio."
        except sr.RequestError:
            return "Error al solicitar resultados del servicio de reconocimiento."

def texto_a_audio(text):
    if text:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()

def audio_texto_audio(filepath):
    if filepath:
        audio = AudioSegment.from_file(filepath)
        play(audio)

def texto_a_audio_desde_archivo(filepath):
    if filepath:
        with open(filepath, 'r', encoding='utf-8') as file:
            text = file.read()
            engine = pyttsx3.init()
            engine.say(text)
            engine.runAndWait()
