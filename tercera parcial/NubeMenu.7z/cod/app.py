from flask import Flask, request, jsonify, render_template, send_file
import pyttsx3
import speech_recognition as sr
from sentiment_analysis_spanish import sentiment_analysis
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk import pos_tag, ne_chunk
from nltk.tokenize import word_tokenize
from nltk.chunk import RegexpParser
import subprocess
import os
import io
from pydub import AudioSegment
import wave

# Descargar recursos necesarios para NLTK
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('maxent_ne_chunker')
nltk.download('words')
nltk.download('vader_lexicon')

app = Flask(__name__)

# Crear instancia del analizador de sentimientos en español
analizador_es = sentiment_analysis.SentimentAnalysisSpanish()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analizar', methods=['POST'])
def analizar():
    data = request.json
    text = data['text']
    language = data['language']
    if language == 'en':
        analyzer = SentimentIntensityAnalyzer()
        scores = analyzer.polarity_scores(text)
    elif language == 'es':
        puntuacion = analizador_es.sentiment(text)
        scores = {"score": puntuacion, "sentiment": interpretar_sentimiento(puntuacion)}
    else:
        return jsonify({"error": "Invalid language"}), 400
    return jsonify(scores)

@app.route('/grabar_audio', methods=['POST'])
def grabar_audio():
    file = request.files['file']
    recognizer = sr.Recognizer()
    audio = sr.AudioFile(file)
    with audio as source:
        audio_data = recognizer.record(source)
        try:
            text = recognizer.recognize_google(audio_data, language='es-ES')
            return jsonify({"text": text})
        except sr.UnknownValueError:
            return jsonify({"error": "No se pudo entender el audio."}), 400
        except sr.RequestError:
            return jsonify({"error": "Error al solicitar resultados del servicio de reconocimiento."}), 500

@app.route('/convertir_a_exe', methods=['POST'])
def convertir_a_exe():
    file = request.files['file']
    filepath = os.path.join("/tmp", file.filename)
    file.save(filepath)
    result = subprocess.run(['pyinstaller', '--onefile', filepath], capture_output=True, text=True)
    if result.returncode == 0:
        exe_path = filepath.replace('.py', '.exe')
        return send_file(exe_path, as_attachment=True)
    else:
        return jsonify({"error": f"No se pudo convertir el archivo. Error: {result.stderr}"}), 500

@app.route('/texto_a_audio', methods=['POST'])
def texto_a_audio():
    data = request.json
    text = data['text']
    engine = pyttsx3.init()
    engine.save_to_file(text, 'output.mp3')
    engine.runAndWait()
    return send_file('output.mp3', as_attachment=True)

@app.route('/audio_texto_audio', methods=['POST'])
def audio_texto_audio():
    file = request.files['file']
    recognizer = sr.Recognizer()
    audio = sr.AudioFile(file)
    with audio as source:
        audio_data = recognizer.record(source)
        try:
            text = recognizer.recognize_google(audio_data, language='es-ES')
            engine = pyttsx3.init()
            engine.save_to_file(text, 'output.mp3')
            engine.runAndWait()
            return send_file('output.mp3', as_attachment=True)
        except sr.UnknownValueError:
            return jsonify({"error": "No se pudo entender el audio."}), 400
        except sr.RequestError:
            return jsonify({"error": "Error al solicitar resultados del servicio de reconocimiento."}), 500

@app.route('/texto_a_audio_desde_archivo', methods=['POST'])
def texto_a_audio_desde_archivo():
    file = request.files['file']
    filepath = os.path.join("/tmp", file.filename)
    file.save(filepath)
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()
        engine = pyttsx3.init()
        engine.save_to_file(text, 'output.mp3')
        engine.runAndWait()
        return send_file('output.mp3', as_attachment=True)

@app.route('/chat_gpt', methods=['POST'])
def chat_gpt():
    # Aquí puedes agregar el código para simular el chat GPT
    return jsonify({"message": "Esta función está en desarrollo."})

@app.route('/chunking', methods=['POST'])
def chunking():
    text = request.json['text']
    tokens = word_tokenize(text)
    tagged = pos_tag(tokens)
    grammar = "NP: {<DT>?<JJ>*<NN>}"
    cp = RegexpParser(grammar)
    result = cp.parse(tagged)
    return jsonify({"result": str(result)})

@app.route('/ne_chunking', methods=['POST'])
def ne_chunking():
    text = request.json['text']
    tokens = word_tokenize(text)
    tagged = pos_tag(tokens)
    entities = ne_chunk(tagged)
    return jsonify({"result": str(entities)})

@app.route('/analisis_pln', methods=['POST'])
def analisis_pln():
    # Aquí puedes agregar el código para el análisis de PLN
    return jsonify({"message": "Esta función está en desarrollo."})

def interpretar_sentimiento(puntuacion):
    if puntuacion > 0.6:
        return "positivo"
    elif puntuacion < 0.4:
        return "negativo"
    else:
        return "neutral"

if __name__ == '__main__':
    app.run(debug=True)
