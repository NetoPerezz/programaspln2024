from sentiment_analysis_spanish import sentiment_analysis
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk import pos_tag, ne_chunk
from nltk.tokenize import word_tokenize
from nltk.chunk import RegexpParser
import nltk

# Descargar recursos necesarios para NLTK
nltk.download('vader_lexicon')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('maxent_ne_chunker')
nltk.download('words')

# Crear instancia del analizador de sentimientos en español
analizador_es = sentiment_analysis.SentimentAnalysisSpanish()

def analizar_sentimientos_ingles(text):
    sia = SentimentIntensityAnalyzer()
    scores = sia.polarity_scores(text)
    return {
        "text": text,
        "scores": scores,
        "sentiment": interpretar_sentimiento(scores['compound'])
    }

def analizar_sentimientos_espanol(text):
    puntuacion = analizador_es.sentiment(text)
    sentimiento = interpretar_sentimiento(puntuacion)
    return {
        "text": text,
        "score": puntuacion,
        "sentiment": sentimiento
    }

def interpretar_sentimiento(puntuacion):
    if puntuacion > 0.6:
        return "positivo"
    elif puntuacion < 0.4:
        return "negativo"
    else:
        return "neutral"

def chunking(text):
    tokens = word_tokenize(text)
    tagged = pos_tag(tokens)
    grammar = "NP: {<DT>?<JJ>*<NN>}"
    cp = RegexpParser(grammar)
    result = cp.parse(tagged)
    return result

def ne_chunking(text):
    tokens = word_tokenize(text)
    tagged = pos_tag(tokens)
    entities = ne_chunk(tagged)
    return entities
